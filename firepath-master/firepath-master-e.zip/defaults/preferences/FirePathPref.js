pref("extensions.firebug.firepath.showParentToolbar", false);
pref("extensions.firebug.firepath.generateAbsoluteXPath", false);
pref("extensions.firebug.firepath.showDOM", true);
pref("extensions.firebug.firepath.evaluationMode", "xpath");